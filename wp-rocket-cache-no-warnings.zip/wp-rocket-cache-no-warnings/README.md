# WP Rocket | No Warnings

Stops WP Rocket from showing warnings if advanced-cache.php and / or .htaccess aren't writable.

🚧&#160;&#160;**ADVANCED CUSTOMIZATION, HANDLE WITH CARE!**

To be used with:
* any setup where WP Rockets's page caching functionality is not to be used while still using the plugin

Last tested with:
* WP Rocket 3.8.3
* WordPress 5.6.x